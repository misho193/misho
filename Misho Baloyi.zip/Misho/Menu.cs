﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Misho
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void BtnSurvey_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalInfo personal = new PersonalInfo(); //this is the change, code for redirect to fill personal info form 
            personal.ShowDialog();
        }

        private void BtnResults_Click(object sender, EventArgs e)
        {
            this.Hide();
            Survey survey = new Survey(); //this is the change, code for redirect to Survey form 
            survey.ShowDialog();
        }
    }
}
