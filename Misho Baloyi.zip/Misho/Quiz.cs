﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Misho
{
    public partial class Quiz : Form
    {
        public Quiz()
        {
            InitializeComponent();
        }

        private void Quiz_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"data source=(local);initial catalog=survey;persist security info=True;user id=sa;password=P@SSW0RD;pooling=False;MultipleActiveResultSets=True");
            con.Open();
            SqlCommand com = new SqlCommand("select questionId,question from tblQuestion where questionId = 1", con);
            SqlCommand user = new SqlCommand("select max(userId) from tblUser", con);
            SqlCommand quiz = new SqlCommand("select questionId,question from tblQuestion where questionId not in (1)", con);
            SqlCommand quiz1 = new SqlCommand("select questionId,question from tblQuestion where questionId not in (1)", con);
            SqlCommand quiz2 = new SqlCommand("select questionId,question from tblQuestion where questionId not in (1)", con);
            SqlCommand quiz3 = new SqlCommand("select questionId,question from tblQuestion where questionId not in (1)", con);
            SqlDataReader reader = com.ExecuteReader();
            SqlDataReader reader1 = user.ExecuteReader();
            SqlDataReader reader2 = quiz.ExecuteReader();
            SqlDataReader reader3 = quiz.ExecuteReader();
            SqlDataReader reader4 = quiz.ExecuteReader();
            SqlDataReader reader5 = quiz.ExecuteReader();

            reader.Read();
            //Display user identity from user table
            label1.Text = reader["userId"].ToString();

            //Display the questions saved in the database to the labels displayed below for the first qiestion
            label7.Text = reader1["questionId"].ToString();
            label6.Text = reader1["question"].ToString();

            //Display the questions saved in the database to the tables shown in the table
            label2.Text = reader2["questionId"].ToString();
            label3.Text = reader3["questionId"].ToString();
            label4.Text = reader4["questionId"].ToString();
            label5.Text = reader5["questionId"].ToString();

            label9.Text = reader2["question"].ToString();
            label10.Text = reader3["question"].ToString();
            label11.Text = reader4["question"].ToString();
            label12.Text = reader5["question"].ToString();
            con.Close();
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu menu = new Menu(); //this is the change, code for redirect to menu form 
            menu.ShowDialog();
        }
    }
}
