﻿namespace Misho
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnResults = new System.Windows.Forms.Button();
            this.BtnSurvey = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnResults
            // 
            this.BtnResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnResults.Location = new System.Drawing.Point(201, 117);
            this.BtnResults.Name = "BtnResults";
            this.BtnResults.Size = new System.Drawing.Size(145, 42);
            this.BtnResults.TabIndex = 5;
            this.BtnResults.Text = "View survey results";
            this.BtnResults.UseVisualStyleBackColor = true;
            this.BtnResults.Click += new System.EventHandler(this.BtnResults_Click);
            // 
            // BtnSurvey
            // 
            this.BtnSurvey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSurvey.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BtnSurvey.Location = new System.Drawing.Point(201, 68);
            this.BtnSurvey.Name = "BtnSurvey";
            this.BtnSurvey.Size = new System.Drawing.Size(145, 42);
            this.BtnSurvey.TabIndex = 4;
            this.BtnSurvey.Text = "Fill out suvey";
            this.BtnSurvey.UseVisualStyleBackColor = true;
            this.BtnSurvey.Click += new System.EventHandler(this.BtnSurvey_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 264);
            this.Controls.Add(this.BtnResults);
            this.Controls.Add(this.BtnSurvey);
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnResults;
        private System.Windows.Forms.Button BtnSurvey;
    }
}